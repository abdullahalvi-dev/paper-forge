/*
 * Roman Urdu comments:
 * Ye utility question text cleanup ke liye use hoti hai.
 * MCQ/SHORT/LONG prefixes aur numbering remove karke clean printable question text return karti hai.
 */
const cleanQuestionText = (value) =>
  String(value || '')
    .replace(/^\s*(?:mcqs?|short(?:\s+questions?)?|long(?:\s+questions?)?|questions?)\s*\d+\s*[:.)-]\s*/i, '')
    .replace(/^\s*\d+\s*[:.)-]\s*/, '')
    .trim();

module.exports = {
  cleanQuestionText
};
