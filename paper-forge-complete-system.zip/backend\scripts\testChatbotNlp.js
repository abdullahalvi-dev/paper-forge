/*
 * Roman Urdu comments:
 * Ye smoke tests chatbot NLP parser aur multi-turn merge ko verify karte hain.
 * Tests DB ke baghair local question-bank metadata se run ho sakte hain.
 */
const assert = require('assert');
const { fallbackParse } = require('../services/nlpService');
const { mergeParsedWithPending } = require('../services/chatbotContextService');
const { getQuestionBankMetadata } = require('../services/questionBankMetadataService');

const hasValue = (value) => Boolean(String(value || '').trim());

const run = async () => {
  const metadata = await getQuestionBankMetadata({ forceRefresh: true });

  metadata.classes.forEach((classItem) => {
    classItem.subjects.forEach((subjectItem) => {
      if (!subjectItem.chapters.length) return;
      const parsed = fallbackParse(
        `${classItem.name} ${subjectItem.name} chapter 1 paper 2 mcq 1 short 1 long`,
        'teacher',
        metadata
      );
      assert.strictEqual(parsed.intent, 'generate_paper', `${classItem.name} ${subjectItem.name}`);
      assert.strictEqual(parsed.classLevel, classItem.name, `${classItem.name} ${subjectItem.name}`);
      assert.strictEqual(parsed.subject, subjectItem.name, `${classItem.name} ${subjectItem.name}`);
      assert(parsed.chapters.includes('1'), `${classItem.name} ${subjectItem.name}`);
      assert.strictEqual(parsed.mcqCount, 2, `${classItem.name} ${subjectItem.name}`);
      assert.strictEqual(parsed.shortCount, 1, `${classItem.name} ${subjectItem.name}`);
      assert.strictEqual(parsed.longCount, 1, `${classItem.name} ${subjectItem.name}`);
    });
  });

  metadata.questionTypes.forEach((typeItem) => {
    const parsed = fallbackParse(`computer science ${typeItem.name} 3`, 'student', metadata);
    assert(parsed.questionTypes.includes(typeItem.name), typeItem.name);
    assert.strictEqual(parsed.questionCounts[typeItem.name], 3, typeItem.name);
  });

  const cases = [
    {
      role: 'teacher',
      message: 'mujh ko 9 class ka chemistry chapter 1 ka paper bna do',
      expect: { intent: 'generate_paper', classLevel: '9th', subject: 'Chemistry', chapter: '1' }
    },
    {
      role: 'teacher',
      message: '10 class math 5 chapter 10 mcq 5 short 2 long',
      expect: { intent: 'generate_paper', classLevel: '10th', subject: 'Math', chapter: '5', mcqCount: 10, shortCount: 5, longCount: 2 }
    },
    {
      role: 'teacher',
      message: '1st year physics chapter 2 ka paper bna do',
      expect: { intent: 'generate_paper', classLevel: '1st Year', subject: 'Physics', chapter: '2' }
    },
    {
      role: 'student',
      message: '2nd year biology chapter 4 se 20 mcqs practice test bna do',
      expect: { intent: 'generate_practice', classLevel: '2nd Year', subject: 'Biology', chapter: '4', mcqCount: 20 }
    },
    {
      role: 'teacher',
      message: 'computer science 10th class chapter database se paper bnao',
      expect: { intent: 'generate_paper', classLevel: '10th', subject: 'Computer Science', chapter: 'Database' }
    }
  ];

  cases.forEach((item) => {
    const parsed = fallbackParse(item.message, item.role, metadata);
    assert.strictEqual(parsed.intent, item.expect.intent, item.message);
    assert.strictEqual(parsed.classLevel, item.expect.classLevel, item.message);
    assert.strictEqual(parsed.subject, item.expect.subject, item.message);
    assert(parsed.chapters.includes(item.expect.chapter), item.message);
    if (item.expect.mcqCount !== undefined) assert.strictEqual(parsed.mcqCount, item.expect.mcqCount, item.message);
    if (item.expect.shortCount !== undefined) assert.strictEqual(parsed.shortCount, item.expect.shortCount, item.message);
    if (item.expect.longCount !== undefined) assert.strictEqual(parsed.longCount, item.expect.longCount, item.message);
  });

  const first = fallbackParse('mujh ko 9 class ka paper bna kr do chemistry ky 1 chapter ka', 'teacher', metadata);
  const second = fallbackParse('5 mcq, 3 short, 1 long', 'teacher', metadata);
  const merged = mergeParsedWithPending({
    parsed: second,
    pendingContext: first,
    message: '5 mcq, 3 short, 1 long',
    role: 'teacher'
  });

  assert.strictEqual(merged.intent, 'generate_paper');
  assert.strictEqual(merged.classLevel, '9th');
  assert.strictEqual(merged.subject, 'Chemistry');
  assert(merged.chapters.includes('1'));
  assert.strictEqual(merged.mcqCount, 5);
  assert.strictEqual(merged.shortCount, 3);
  assert.strictEqual(merged.longCount, 1);
  assert(hasValue(merged.subject));

  console.log('Chatbot NLP tests passed');
};

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
