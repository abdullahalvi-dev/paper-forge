/*
 * Roman Urdu comments:
 * Ye controller chatbot API handle karta hai.
 * Flow: user message -> AI/fallback JSON parser -> pending context merge -> backend validation -> existing generation service.
 */
const Paper = require('../models/Paper');
const { parseUserCommand, generateExplanation } = require('../services/nlpService');
const { createBoardPaper } = require('../services/paperService');
const { createPracticeAttempt, hidePracticeAnswers } = require('../services/practiceService');
const { consumeTrialOrRequireSubscription } = require('../services/subscriptionService');
const {
  getQuestionBankMetadata,
  resolveClassLevel,
  resolveSubject,
  resolveChapters
} = require('../services/questionBankMetadataService');
const {
  clearPendingContext,
  getPendingContext,
  mergeParsedWithPending,
  savePendingContext
} = require('../services/chatbotContextService');

const roleCan = {
  generate_paper: ['teacher', 'admin'],
  generate_practice: ['student', 'admin'],
  explain_answer: ['student', 'admin'],
  generate_answer_key: ['teacher', 'admin'],
  generate_study_plan: ['student', 'teacher', 'admin'],
  weak_topic_analysis: ['student', 'teacher', 'admin'],
  unknown: ['student', 'teacher', 'admin']
};

const compact = (items) => [...new Set((items || []).filter(Boolean))];

const followUp = (res, parsed, message) =>
  res.json({
    intent: parsed.intent,
    parsed,
    needsFollowUp: true,
    message
  });

const requireAllowedRole = (intent, role) => {
  if ((roleCan[intent] || []).includes(role)) return null;
  const error = new Error('Your role is not allowed to use this chatbot command.');
  error.statusCode = 403;
  return error;
};

const followUpMessage = (missing = []) => {
  const fields = compact(missing);
  if (fields.length === 1 && fields.includes('subject')) return 'Subject ka naam bata dein.';
  if (fields.length === 1 && fields.includes('chapters')) return 'Chapter number ya chapter name bata dein.';
  if (fields.includes('question counts')) return 'MCQs, short aur long questions kitne chahiye?';
  if (fields.includes('mcqCount')) return 'MCQs kitne chahiye?';
  if (fields.length === 1 && fields.includes('classLevel')) return 'Class ka naam bata dein.';

  const labels = [];
  if (fields.includes('classLevel')) labels.push('class');
  if (fields.includes('subject')) labels.push('subject');
  if (fields.includes('chapters')) labels.push('chapter');
  if (labels.length) return `${labels.join(', ')} bata dein.`;

  return 'Missing details bata dein taake request complete ho sake.';
};

const hasAnyQuestionCounts = (parsed) =>
  Boolean(
    Number(parsed.mcqCount || 0) ||
      Number(parsed.shortCount || 0) ||
      Number(parsed.longCount || 0) ||
      Object.keys(parsed.questionCounts || {}).length
  );

const generationDifficulty = (difficulty) => (['easy', 'medium', 'hard'].includes(difficulty) ? difficulty : 'mixed');

const validateCommonAcademicFields = (parsed, metadata) => {
  const missing = [];
  const classLevel = resolveClassLevel(parsed.classLevel, metadata);
  const subject = resolveSubject(parsed.subject, classLevel, metadata);

  if (!classLevel) missing.push('classLevel');
  if (!subject) missing.push('subject');
  if (!parsed.chapters.length) missing.push('chapters');

  if (missing.length) {
    return {
      ok: false,
      missing,
      message: followUpMessage(missing)
    };
  }

  const chapterResolution = resolveChapters({ classLevel, subject, chapters: parsed.chapters }, metadata);
  if (!chapterResolution.chapters.length || chapterResolution.unresolved.length) {
    return {
      ok: false,
      missing: ['chapters'],
      message: chapterResolution.available.length
        ? `Chapter samajh nahi aya. Available chapters: ${chapterResolution.available.join(', ')}.`
        : 'Is class aur subject ke liye chapter data nahi mila. Pehle question-bank me chapter add karein.'
    };
  }

  return {
    ok: true,
    classLevel,
    subject,
    chapters: chapterResolution.chapters
  };
};

const validatePaperCommand = (parsed, metadata) => {
  const academic = validateCommonAcademicFields(parsed, metadata);
  if (!academic.ok) return academic;

  if (!hasAnyQuestionCounts(parsed)) {
    return {
      ok: false,
      missing: ['question counts'],
      message: followUpMessage(['question counts'])
    };
  }

  return academic;
};

const validatePracticeCommand = (parsed, metadata) => {
  const academic = validateCommonAcademicFields(parsed, metadata);
  if (!academic.ok) return academic;

  if (!parsed.mcqCount) {
    return {
      ok: false,
      missing: ['mcqCount'],
      message: followUpMessage(['mcqCount'])
    };
  }

  return academic;
};

const withMissing = (parsed, missing) => ({
  ...parsed,
  missingFields: compact([...(parsed.missingFields || []), ...missing]),
  confirmationRequired: true
});

const paperAnswerKey = (paper) =>
  paper.questions
    .filter((question) => question.type === 'mcq')
    .map((question, index) => ({
      number: index + 1,
      question: question.question,
      answer: question.correctAnswer || 'Teacher review required'
    }));

const generateStudyPlan = (parsed, academic) => {
  const chapters = academic?.chapters?.length ? academic.chapters : parsed.chapters;
  const subject = academic?.subject || parsed.subject || 'Subject';
  const classLevel = academic?.classLevel || parsed.classLevel || 'Class';
  return [
    `Day 1: ${classLevel} ${subject} ka syllabus overview aur formulas/key terms revise karein.`,
    `Day 2: ${chapters[0] || 'selected chapter'} ke basic concepts aur definitions cover karein.`,
    'Day 3: MCQs practice karein aur wrong answers ki short notes list banayein.',
    'Day 4: Short questions likh kar timing improve karein.',
    'Day 5: Long questions ke headings, diagrams, and examples prepare karein.',
    'Day 6: Mixed practice paper attempt karein.',
    'Day 7: Weak topics revise karein aur final answer key review karein.'
  ];
};

const handlePendingFollowUp = async (req, res, parsed, validation) => {
  const pendingParsed = withMissing(parsed, validation.missing);
  await savePendingContext(req.user, pendingParsed, pendingParsed.missingFields);
  return followUp(res, pendingParsed, validation.message);
};

const handleChatbotMessage = async (req, res, next) => {
  try {
    const message = String(req.body.message || '').trim();
    if (!message) return res.status(400).json({ message: 'Chat message is required.' });
    if (message.length > 2000) return res.status(400).json({ message: 'Chat message is too long.' });

    const metadata = await getQuestionBankMetadata();
    const parsedMessage = await parseUserCommand(message, req.user.role, metadata);
    const pendingContext = await getPendingContext(req.user._id);
    const parsed = mergeParsedWithPending({
      parsed: parsedMessage,
      pendingContext,
      message,
      role: req.user.role
    });

    const roleError = requireAllowedRole(parsed.intent, req.user.role);
    if (roleError) throw roleError;

    if (parsed.intent === 'unknown') {
      const pendingParsed = withMissing(parsed, ['intent']);
      await savePendingContext(req.user, pendingParsed, pendingParsed.missingFields);
      return followUp(
        res,
        pendingParsed,
        'Please tell me what you want: generate paper, generate practice, explain answer, answer key, or study plan.'
      );
    }

    if (parsed.intent === 'generate_paper') {
      const validation = validatePaperCommand(parsed, metadata);
      if (!validation.ok) return handlePendingFollowUp(req, res, parsed, validation);

      await consumeTrialOrRequireSubscription(req.user, 'paper_generation');
      const paper = await createBoardPaper(req.user._id, {
        title: `${validation.subject} ${validation.classLevel} AI Chat Paper`,
        classLevel: validation.classLevel,
        subject: validation.subject,
        chapters: validation.chapters,
        mode: parsed.generationMode === 'question_bank' ? 'custom' : 'custom',
        mcqCount: parsed.mcqCount,
        shortCount: parsed.shortCount,
        longCount: parsed.longCount,
        marksPerQuestion: parsed.marks,
        difficulty: generationDifficulty(parsed.difficulty)
      });
      await clearPendingContext(req.user._id);

      return res.status(201).json({
        intent: parsed.intent,
        parsed: {
          ...parsed,
          classLevel: validation.classLevel,
          subject: validation.subject,
          chapters: validation.chapters,
          missingFields: [],
          confirmationRequired: false
        },
        needsFollowUp: false,
        message: 'Paper generated successfully from question bank.',
        paper
      });
    }

    if (parsed.intent === 'generate_practice') {
      const validation = validatePracticeCommand(parsed, metadata);
      if (!validation.ok) return handlePendingFollowUp(req, res, parsed, validation);

      await consumeTrialOrRequireSubscription(req.user, 'practice_session');
      const practice = await createPracticeAttempt(req.user._id, {
        classLevel: validation.classLevel,
        subject: validation.subject,
        chapters: validation.chapters,
        count: parsed.mcqCount,
        difficulty: generationDifficulty(parsed.difficulty)
      });
      await clearPendingContext(req.user._id);

      return res.status(201).json({
        intent: parsed.intent,
        parsed: {
          ...parsed,
          classLevel: validation.classLevel,
          subject: validation.subject,
          chapters: validation.chapters,
          missingFields: [],
          confirmationRequired: false
        },
        needsFollowUp: false,
        message: 'Practice paper generated successfully.',
        practice: hidePracticeAnswers(practice)
      });
    }

    if (parsed.intent === 'explain_answer') {
      await clearPendingContext(req.user._id);
      const explanation = await generateExplanation(message, parsed);
      return res.json({
        intent: parsed.intent,
        parsed,
        needsFollowUp: false,
        message: explanation,
        explanation
      });
    }

    if (parsed.intent === 'generate_answer_key') {
      const paperId = req.body.paperId || req.body.context?.paperId;
      if (!paperId) {
        const pendingParsed = withMissing(parsed, ['paperId']);
        await savePendingContext(req.user, pendingParsed, pendingParsed.missingFields);
        return followUp(res, pendingParsed, 'Please select or generate a paper first, then I can create the answer key.');
      }

      const paper = await Paper.findById(paperId);
      if (!paper) return res.status(404).json({ message: 'Paper not found.' });
      const ownsPaper = String(paper.teacherId) === String(req.user._id);
      if (!ownsPaper && req.user.role !== 'admin') return res.status(403).json({ message: 'You cannot access this paper.' });

      await clearPendingContext(req.user._id);
      return res.json({
        intent: parsed.intent,
        parsed,
        needsFollowUp: false,
        message: 'Answer key generated.',
        answerKey: paperAnswerKey(paper)
      });
    }

    if (parsed.intent === 'generate_study_plan') {
      const academic = validateCommonAcademicFields(parsed, metadata);
      if (!academic.ok) return handlePendingFollowUp(req, res, parsed, academic);

      await clearPendingContext(req.user._id);
      return res.json({
        intent: parsed.intent,
        parsed,
        needsFollowUp: false,
        message: 'Study plan generated.',
        studyPlan: generateStudyPlan(parsed, academic)
      });
    }

    if (parsed.intent === 'weak_topic_analysis') {
      const academic = validateCommonAcademicFields(parsed, metadata);
      if (!academic.ok) return handlePendingFollowUp(req, res, parsed, academic);

      await clearPendingContext(req.user._id);
      return res.json({
        intent: parsed.intent,
        parsed,
        needsFollowUp: false,
        message: 'Weak topic analysis ready.',
        analysis: [
          `${academic.subject} me ${academic.chapters.join(', ')} ke MCQs, short answers, aur long answers separately attempt karein.`,
          'Jis type me score kam aaye us chapter ke definitions, formulas, aur board-style examples revise karein.',
          'Next practice me wrong-answer notebook maintain karein taake repeated mistakes clear ho saken.'
        ]
      });
    }

    return followUp(res, parsed, 'Please rephrase your request with class, subject, chapters, and counts.');
  } catch (error) {
    next(error);
  }
};

module.exports = {
  handleChatbotMessage
};
