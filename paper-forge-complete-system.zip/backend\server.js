/*
 * Roman Urdu comments:
 * Ye file Paper Forge API ka main server setup karti hai.
 * Is mein Express app, CORS, static frontend hosting, API routes, health check, 404 aur global error handling register hotay hain.
 */
const path = require('path');
const cors = require('cors');
const dotenv = require('dotenv');
const express = require('express');
const morgan = require('morgan');
const connectDB = require('./config/db');

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;
const frontendPath = path.join(__dirname, '..', 'frontend');
const clientOrigins = (process.env.CLIENT_URL || '')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);
const isLocalDevOrigin = (origin = '') => /^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/i.test(origin);
const corsOptions = {
  origin(origin, callback) {
    if (!origin || origin === 'null') return callback(null, true);
    if (process.env.CORS_ALLOW_ALL === 'true') return callback(null, true);
    if (clientOrigins.includes(origin) || isLocalDevOrigin(origin)) return callback(null, true);
    return callback(null, false);
  },
  credentials: true
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'Paper Forge API' });
});

app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/teacher', require('./routes/teacherRoutes'));
app.use('/api/student', require('./routes/studentRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));
app.use('/api/papers', require('./routes/paperRoutes'));
app.use('/api/paper', require('./routes/paperRoutes'));
app.use('/api/questions', require('./routes/questionRoutes'));
app.use('/api/resources', require('./routes/resourceRoutes'));
app.use('/api/subscription', require('./routes/subscriptionRoutes'));
app.use('/api/practice', require('./routes/practiceRoutes'));
app.use('/api/chatbot', require('./routes/chatbotRoutes'));

app.use(express.static(frontendPath));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  return res.sendFile(path.join(frontendPath, 'index.html'));
});

app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

app.use((error, req, res, next) => {
  const statusCode = error.statusCode || 500;
  res.status(statusCode).json({
    message: error.message || 'Server error'
  });
});

connectDB()
  .then(() => {
    app.listen(port, () => {
      console.log(`Paper Forge running on http://localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error(error.message);
    process.exit(1);
  });
