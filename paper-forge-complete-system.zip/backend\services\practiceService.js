/*
 * Roman Urdu comments:
 * Ye service practice test create karne ka reusable logic rakhti hai.
 * Student controller aur chatbot dono isi service ko use karte hain taa ke behavior same rahe.
 */
const Practice = require('../models/Practice');
const { generateQuestions, normalizeArray } = require('./aiEngine');
const { getSettings } = require('./settingsService');

const hidePracticeAnswers = (practice) => {
  const practiceObject = practice.toObject ? practice.toObject() : practice;
  if (practiceObject.status === 'submitted') return practiceObject;

  practiceObject.questions = practiceObject.questions.map((question) => ({
    ...question,
    correctAnswer: undefined,
    explanation: undefined
  }));

  return practiceObject;
};

const createPracticeAttempt = async (userId, payload = {}) => {
  const settings = await getSettings();
  const filters = {
    subject: payload.subject,
    subjectId: payload.subjectId || payload.subject,
    classLevel: payload.classLevel || payload.class,
    classId: payload.classId || payload.classLevel || payload.class,
    chapters: normalizeArray(payload.chapters || payload.chapter),
    chapterIds: normalizeArray(payload.chapterIds || payload.chapterId || payload.chapters || payload.chapter),
    difficulty: payload.difficulty || 'mixed',
    questionTypes: ['mcq'],
    count: Number(payload.count || payload.mcqCount || payload.limit || payload.numberOfQuestions || settings.paperLimits.practiceMcqLimit || 20)
  };

  const questions = await generateQuestions(filters);
  if (!questions.length) {
    const error = new Error('No practice questions found for the selected filters');
    error.statusCode = 404;
    throw error;
  }

  const totalMarks = questions.reduce((sum, question) => sum + Number(question.marks || 0), 0);
  return Practice.create({
    studentId: userId,
    filters,
    questions,
    totalMarks,
    durationPerQuestion: settings.paperLimits.durationPerMcqSeconds || 60
  });
};

module.exports = {
  createPracticeAttempt,
  hidePracticeAnswers
};
